# 🧠 MemoryWeaver-AI

Multimodal generative AI Streamlit app that transforms textual memories into emotion-driven visualizations and optional narrated audio.

**GitHub:** https://github.com/kumar123saanu/MemoryWeaver-AI

## What’s inside
- `streamlit_app.py` — Streamlit frontend (single-file app for Hugging Face Spaces)
- `app/model_utils.py` — model loading and generation helpers
- `app/emotion_prompt_engine.py` — emotion classification & prompt enrichment
- `app/audio_generator.py` — gTTS-based narration
- `requirements.txt` — Python dependencies
- `Procfile` & `runtime.txt` — included for optional alternate hosting
- `.gitignore`

## Deploy to Hugging Face Spaces (Streamlit)
1. Create a new **Space** on Hugging Face, choose **Streamlit** as SDK.
2. Upload everything from this repository (or push to a GitHub repo and connect that repo to the Space).
3. In your Space settings, set a `HF_TOKEN` secret (if you want to load private models). For public models this is optional.
4. Start the Space. If you need GPU, enable the `Hardware accelerator` in Space settings.

> Notes:
- Stable-diffusion model weights are large; using a hosted GPU is recommended for reasonable speed.
- If you don't have GPU, model inference will be much slower on CPU and may fail due to memory limits.
