import streamlit as st
from PIL import Image
import os
from app.emotion_prompt_engine import enrich_prompt
from app.audio_generator import generate_audio
from app.model_utils import load_diffusion_model, generate_image

st.set_page_config(page_title="MemoryWeaver", page_icon="🧠", layout="wide")
st.title("🧠 MemoryWeaver – Multimodal Generative AI")

st.markdown("""Write a short memory or moment and MemoryWeaver will:
- Detect the primary emotion
- Generate an emotion-guided image (Stable Diffusion)
- Optionally narrate the memory using gTTS
""")

with st.sidebar:
    st.header("Settings")
    use_audio = st.checkbox("Enable audio narration (gTTS)", value=True)
    model_id = st.text_input("Diffusion model id", value="runwayml/stable-diffusion-v1-5")
    num_steps = st.slider("Inference steps", 10, 50, 25)
    guidance = st.slider("Guidance scale", 1.0, 12.0, 7.5)

memory_text = st.text_area("💭 Describe your memory", height=200, placeholder="E.g., 'The smell of rain on hot asphalt, walking to the old cafe with my sister...'")

if st.button("Weave my memory"):
    if not memory_text.strip():
        st.warning("Please enter some text.")
    else:
        with st.spinner("Analyzing emotion..."):
            prompt, emotion = enrich_prompt(memory_text)
        st.success(f"Emotion detected: {emotion}")

        with st.spinner("Loading model (this may take a while first run)..."):
            pipe = load_diffusion_model(model_id)

        out_image = "generated_memory.png"
        with st.spinner("Generating image..."):
            generate_image(pipe, prompt, out_path=out_image, num_inference_steps=num_steps, guidance_scale=guidance)
        st.image(out_image, caption=f"Generated memory — {emotion}", use_column_width=True)

        if use_audio:
            with st.spinner("Generating narration..."):
                audio_file = generate_audio(memory_text)
            st.audio(audio_file)

        st.download_button("Download image", data=open(out_image, "rb"), file_name="memory_visualization.png")
        if use_audio:
            st.download_button("Download narration", data=open(audio_file, "rb"), file_name="memory_narration.mp3")
