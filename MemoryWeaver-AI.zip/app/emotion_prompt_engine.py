from transformers import pipeline

# Lightweight emotion model
emotion_classifier = pipeline("text-classification", model="j-hartmann/emotion-english-distilroberta-base")

def enrich_prompt(user_text):
    results = emotion_classifier(user_text)
    # take the top label
    label = results[0]['label'] if isinstance(results, list) else results['label']
    label = label.lower()
    enhanced_prompt = f"A cinematic, emotionally evocative scene that conveys {label}: {user_text}"
    return enhanced_prompt, label
