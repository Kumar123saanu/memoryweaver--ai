import os
from diffusers import StableDiffusionPipeline
import torch

def load_diffusion_model(model_id="runwayml/stable-diffusion-v1-5"):
    # If running on Spaces with GPU, this will use it automatically.
    device = "cuda" if torch.cuda.is_available() else "cpu"
    pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float16 if device=="cuda" else torch.float32)
    pipe = pipe.to(device)
    # Reduce memory by enabling attention slicing
    try:
        pipe.enable_attention_slicing()
    except Exception:
        pass
    return pipe

def generate_image(pipe, prompt, out_path="generated_memory.png", guidance_scale=7.5, num_inference_steps=25):
    image = pipe(prompt, guidance_scale=guidance_scale, num_inference_steps=num_inference_steps).images[0]
    image.save(out_path)
    return out_path
