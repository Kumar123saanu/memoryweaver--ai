from gtts import gTTS

def generate_audio(text, filename="memory_audio.mp3", lang="en"):
    tts = gTTS(text=text, lang=lang)
    tts.save(filename)
    return filename
